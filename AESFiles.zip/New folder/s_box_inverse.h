//
// Created by Jeeves on 11/8/2018.
//

#ifndef CRYPTOGRAPHYSCRIPTS_S_BOX_INVERSE_H
#define CRYPTOGRAPHYSCRIPTS_S_BOX_INVERSE_H

#include <fstream>
#include <iostream>

using namespace std;

class SBoxInverse {
public:
    unsigned char substitutionTable[15][15];
    void initializeSBox();
};

#endif //CRYPTOGRAPHYSCRIPTS_S_BOX_INVERSE_H
