#include "s_box_inverse.h"

// Read in both the regular and inverse s-boxes
void SBoxInverse::initializeSBox() {
    //read in regular s-box
    string line;
    ifstream s_box_file;
    s_box_file.open("C:\\Users\\Jeeves\\C++Projects\\CryptographyScripts\\sboxinverse.txt");
    if (s_box_file.is_open()) {
        while (getline(s_box_file, line)) {
            cout << line << "\n";
        }
        s_box_file.close();
    }
}