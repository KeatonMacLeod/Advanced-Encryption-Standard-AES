#include "s_box.h"

// Read in both the regular and inverse s-boxes
void SBox::initializeSBox() {
    //read in regular s-box
    string line;
    ifstream s_box_file;
    s_box_file.open("C:\\Users\\Jeeves\\C++Projects\\CryptographyScripts\\sbox.txt");
    if (s_box_file.is_open()) {
        while (getline(s_box_file, line)) {
            vector<string> vec;
            stringstream ss(line);
            int i;
            while (ss >> i) {
            }
            cout << line << "\n";
        }
        s_box_file.close();
    }
}